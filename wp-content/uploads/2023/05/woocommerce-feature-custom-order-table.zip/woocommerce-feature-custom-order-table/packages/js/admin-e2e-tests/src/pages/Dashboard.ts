/**
 * Internal dependencies
 */
import { BasePage } from './BasePage';

export class Dashboard extends BasePage {
	url = 'wp-admin';
}

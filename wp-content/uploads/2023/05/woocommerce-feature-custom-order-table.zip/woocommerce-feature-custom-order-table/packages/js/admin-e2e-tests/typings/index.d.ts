declare module '@woocommerce/e2e-environment';
declare module '@woocommerce/e2e-utils';

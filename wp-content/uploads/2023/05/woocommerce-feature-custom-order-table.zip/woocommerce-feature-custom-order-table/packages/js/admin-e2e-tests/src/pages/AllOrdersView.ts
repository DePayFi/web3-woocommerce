/**
 * Internal dependencies
 */
import { BasePage } from './BasePage';

export class AllOrdersView extends BasePage {
	url = 'wp-admin/edit.php?post_type=shop_order';
}

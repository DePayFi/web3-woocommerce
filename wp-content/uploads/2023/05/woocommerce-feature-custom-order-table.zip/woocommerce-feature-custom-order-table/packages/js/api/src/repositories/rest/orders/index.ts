/**
 * Internal dependencies
 */
import orderRESTRepository from './order';

export { orderRESTRepository };

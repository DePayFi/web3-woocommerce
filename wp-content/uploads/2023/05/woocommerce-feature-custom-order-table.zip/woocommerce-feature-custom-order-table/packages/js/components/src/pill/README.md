# Pill

Use `Pill` to display a pill element containing child content.

## Usage

```jsx
<Pill>Content</Pill>
```

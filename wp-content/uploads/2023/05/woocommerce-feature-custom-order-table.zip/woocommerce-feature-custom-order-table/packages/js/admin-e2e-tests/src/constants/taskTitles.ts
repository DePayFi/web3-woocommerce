export const TaskTitles = {
	storeDetails: 'Store details',
	addPayments: 'Set up payments',
	wooPayments:
		'Set up WooCommerce PaymentsBy setting up, you are agreeing to the Terms of Service2 minutes',
	addProducts: 'Add my products',
	taxSetup: 'Set up tax rates',
	setUpShippingCosts: 'Set up shipping',
	personalizeStore: 'Personalize my store',
};

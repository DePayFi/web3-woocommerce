/**
 * Internal dependencies
 */
import { BasePage } from './BasePage';

export class NewCoupon extends BasePage {
	url = 'wp-admin/post-new.php?post_type=shop_coupon';
}

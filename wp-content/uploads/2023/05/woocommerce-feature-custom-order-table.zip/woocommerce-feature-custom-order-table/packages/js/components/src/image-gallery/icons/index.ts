export * from './cover-image-icon';

/**
 * Internal dependencies
 */
import { BasePage } from './BasePage';

export class PermalinkSettings extends BasePage {
	url = 'wp-admin/options-permalink.php';
}

export { Pill as default } from './pill';
